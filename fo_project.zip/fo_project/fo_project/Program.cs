﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ConsoleApp8
{
    class Program
    {
        static void Main(string[] args)
        {
            string choice = " ";
            while (true)
            {
                var file = @"case1.txt";
                Console.WriteLine("Please enter 1 to first test case, enter 2 to secound test case2, enter 3 to third test case3, enter 4 to fourth test case4, enter 5 to fifth test case5 enter y to terminate");
                string num = Console.ReadLine();
                if (num == "1")
                {
                    file = @"case1.txt";
                }
                else if (num == "2")
                {
                    file = @"case2.txt";
                }
                else if (num == "3")
                {
                    file = @"case3.txt";
                }
                else if (num == "4")
                {
                    file = @"case4.txt";
                }
                else if (num == "5")
                {
                    file = @"case5.txt";
                }else if ( num == "y")
                {

                    break;
                }
                FileStream fs = new FileStream(file, FileMode.Open);
                StreamReader sr = new StreamReader(fs);
               
                String g = "l";
                List<Tuple<string, string, int>> a = new List<Tuple<string, string, int>>();
                List<Tuple<string, int, int>> add = new List<Tuple<string, int, int>>();
                List<int> del = new List<int>();
                int frag = 0;
                while (sr.Peek() != -1)
                {
                    String holder = sr.ReadLine();
                    String holder_var = holder.Split('/')[0];
                    if (holder_var.Equals("Add"))
                    {
                        String key = holder.Split('/')[1];
                        int value = Int32.Parse(holder.Split('/')[2]);
                        a.Add(new Tuple<string, string, int>(holder_var, key, value));
                    }
                    else
                    {
                        String key = holder.Split('/')[1];
                        a.Add(new Tuple<string, string, int>(holder_var, key, 0));
                    }

                }
                fs.Close();
                Console.WriteLine("Please enter f to firstfit or b to bestfit");
                string input = Console.ReadLine();
                switch (input)
                {
                    case "f":
                        {
                            for (int i = 0; i < a.Count; i++)
                            {
                                if (a[i].Item1.Equals("Add"))
                                {
                                    if (del.Count == 0)
                                    {
                                        add.Add(new Tuple<string, int, int>(a[i].Item2, a[i].Item3, 0));
                                    }
                                    else
                                    {
                                        for (int y = 0; y <= del.Count; y++)
                                        {
                                            if (del[y] >= a[i].Item3)
                                            {
                                                for (int b = 0; b < add.Count; b++)
                                                {
                                                    if (del[y] == add[b].Item2)
                                                    {
                                                        add[b] = Tuple.Create(a[i].Item2, add[b].Item2, (add[b].Item2 - a[i].Item3));
                                                    }
                                                }
                                                g = "k";
                                            }
                                            del.RemoveAt(y);
                                        }
                                        if (g != "k")
                                        {
                                            add.Add(new Tuple<string, int, int>(a[i].Item2, a[i].Item3, 0));
                                        }
                                    }
                                }
                                else
                                {
                                    for (int j = 0; j < add.Count; j++)
                                    {
                                        if (a[i].Item2.Equals(add[j].Item1))
                                        {
                                            del.Add(add[j].Item2);
                                            int t = add[j].Item2;
                                            add[j] = Tuple.Create(" ", t, add[j].Item3);
                                        }
                                    }
                                }
                            }
                            foreach (var e in add)
                            {
                                Console.WriteLine(e);
                            }
                            for (int i = 0; i < add.Count; i++)
                            {
                                frag += add[i].Item3;
                            }

                            Console.WriteLine("The total fregmantation is equal");
                            Console.WriteLine(frag); 
                            a.Clear();
                            add.Clear();
                            del.Clear();
                            frag = 0;
                        }
                        break;
                    case "b":
                        {
                            for (int i = 0; i < a.Count; i++)
                            {
                                if (a[i].Item1.Equals("Add"))
                                {
                                    if (del.Count == 0)
                                    {
                                        add.Add(new Tuple<string, int, int>(a[i].Item2, a[i].Item3, 0));
                                    }
                                    else
                                    {
                                        for (int y = 0; y <= del.Count; y++)
                                        {
                                            if (del[y] >= a[i].Item3)
                                            {
                                                for (int b = 0; b < add.Count; b++)
                                                {
                                                    if (del[y] == add[b].Item2)
                                                    {
                                                        add[b] = Tuple.Create(a[i].Item2, add[b].Item2, (add[b].Item2 - a[i].Item3));
                                                    }
                                                }
                                                g = "k";
                                            }
                                            del.RemoveAt(y);
                                        }
                                        if (g != "k")
                                        {
                                            add.Add(new Tuple<string, int, int>(a[i].Item2, a[i].Item3, 0));
                                        }
                                    }
                                }
                                else
                                {
                                    for (int j = 0; j < add.Count; j++)
                                    {
                                        if (a[i].Item2.Equals(add[j].Item1))
                                        {
                                            del.Add(add[j].Item2);
                                            del.Sort();
                                            int hh = add[j].Item2;
                                            add[j] = Tuple.Create(" ", hh, add[j].Item3);
                                        }
                                    }
                                }
                            }
                            foreach (var f in add)
                            {
                                Console.WriteLine(f);
                            }
                            for (int i = 0; i < add.Count; i++)
                            {
                                frag += add[i].Item3;
                            }

                            Console.WriteLine("The total fregmantation is equal");
                            Console.WriteLine(frag);
                            add.Clear();
                            del.Clear();
                            a.Clear();
                            frag = 0;
                        }
                        break;
                    
                }

            }
        }
    }
}